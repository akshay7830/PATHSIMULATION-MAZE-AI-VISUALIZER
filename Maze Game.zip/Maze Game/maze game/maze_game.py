"""Maze game with pathfinding visualisation 

Controls
  Arrows / WASD  move              SPACE  solve with selected algorithm
  1-4            pick algorithm    C      compare all algorithms
  G              grid size         L      loops (multiple paths)
  J              stop at junctions R      new maze        ESC  quit

Run:   python maze_game_v2.py [--seed N]
Tests: python -m pytest test_maze_game.py
"""
from __future__ import annotations

import argparse
import heapq
import math
import random
import sys
import time
from dataclasses import dataclass

try:
    import pygame
except ImportError:
    sys.exit('This game needs pygame. Install it with:  pip install pygame')

DIRS = [(-1, 0), (1, 0), (0, -1), (0, 1)]
SIZES = [15, 21, 27, 35]  # odd, so the carving grid lines up
INFO = {
    'bfs': ('BFS', 'O(V + E)', 'O(V)', 'Yes'),
    'dfs': ('DFS', 'O(V + E)', 'O(V)', 'No'),
    'dijkstra': ('Dijkstra', 'O((V + E) log V)', 'O(V)', 'Yes'),
    'greedy': ('Greedy', 'O(E log V) worst', 'O(V)', 'No'),
}
ALGOS = list(INFO)

W, H = 960, 680
MAZE_PX = 540
MARGIN = 20
PANEL_X = 590
FPS = 60
ANIM_STEP = 6        # cells revealed per frame while animating
GLIDE_MS = 30        # delay between glide steps
BENCH_RUNS = 20      # maximum timing repeats
BENCH_BUDGET = 0.03  # seconds; stops timing early so the window never stalls

# Palette: dark UI with a light maze
BG = (15, 23, 42)
CARD = (30, 41, 59)
EDGE = (51, 65, 85)
FLOOR = (241, 245, 249)
WALL = (51, 65, 85)
TEXT = (241, 245, 249)
MUTED = (148, 163, 184)
ACCENT = (251, 146, 60)
START = (34, 197, 94)
GOAL = (244, 63, 94)
PLAYER = (59, 130, 246)
PATH = (250, 204, 21)
VISIT_A = (129, 140, 248)   # first cells visited
VISIT_B = (56, 189, 248)    # last cells visited

MOVE_KEYS = {
    pygame.K_UP: (-1, 0), pygame.K_w: (-1, 0),
    pygame.K_DOWN: (1, 0), pygame.K_s: (1, 0),
    pygame.K_LEFT: (0, -1), pygame.K_a: (0, -1),
    pygame.K_RIGHT: (0, 1), pygame.K_d: (0, 1),
}
ALGO_KEYS = {getattr(pygame, f'K_{i + 1}'): a for i, a in enumerate(ALGOS)}


# 1. Maze generation (randomized DFS / recursive backtracker)
def make_maze(n: int, loops: bool = False, rng=None):
    """Return an n x n grid where 1 is a wall and 0 is a path."""
    if n < 5 or n % 2 == 0:
        raise ValueError('maze size must be an odd number >= 5')
    if rng is None:
        rng = random

    g = [[1] * n for _ in range(n)]
    g[1][1] = 0
    stack = [(1, 1)]
    while stack:
        r, c = stack[-1]
        nb = [
            (r + 2 * dr, c + 2 * dc, dr, dc)
            for dr, dc in DIRS
            if 0 < r + 2 * dr < n - 1
            and 0 < c + 2 * dc < n - 1
            and g[r + 2 * dr][c + 2 * dc]
        ]
        if nb:
            a, b, dr, dc = rng.choice(nb)
            g[r + dr][c + dc] = g[a][b] = 0
            stack.append((a, b))
        else:
            stack.pop()

    if loops:
        for r in range(1, n - 1):
            for c in range(1, n - 1):
                if g[r][c] and rng.random() < 0.1 and (
                    (not g[r][c - 1] and not g[r][c + 1])
                    or (not g[r - 1][c] and not g[r + 1][c])
                ):
                    g[r][c] = 0
    return g


# 2. Pathfinding: one search loop; the priority decides the algorithm.
def search(algo, grid, start, goal):
    """Return (visit_order, path). The path is [] if the goal is unreachable."""
    if algo not in INFO:
        raise ValueError(f'unknown algorithm: {algo}')

    def h(p):
        return abs(p[0] - goal[0]) + abs(p[1] - goal[1])

    size = len(grid)
    dist = {start: 0}
    prev = {start: None}
    closed = set()
    order = []
    heap = [(0, 0, start)]
    count = 0

    while heap:
        _, _, cur = heapq.heappop(heap)
        if cur in closed:
            continue
        closed.add(cur)
        order.append(cur)
        if cur == goal:
            break

        for dr, dc in DIRS:
            nr, nc = cur[0] + dr, cur[1] + dc
            if not (0 <= nr < size and 0 <= nc < size) or grid[nr][nc]:
                continue
            nxt = (nr, nc)
            if nxt in closed:
                continue
            nd = dist[cur] + 1
            if nxt in dist and dist[nxt] <= nd:
                continue
            dist[nxt], prev[nxt] = nd, cur
            count += 1
            pri = {
                'bfs': count,
                'dfs': -count,
                'dijkstra': nd,
                'greedy': h(nxt),
            }[algo]
            heapq.heappush(heap, (pri, count, nxt))

    path = []
    if goal in closed:
        node = goal
        while node is not None:
            path.append(node)
            node = prev[node]
        path.reverse()
    return order, path


def bench(algo, grid, start, goal, budget=BENCH_BUDGET, max_runs=BENCH_RUNS):
    """Time a search, repeating until the budget or run limit is reached.

    Returns (order, path, avg_ms). Fast mazes get the full run count for
    accuracy; slow ones stop early so the window stays responsive.
    """
    runs = 0
    t0 = time.perf_counter()
    while True:
        order, path = search(algo, grid, start, goal)
        runs += 1
        if runs >= max_runs or time.perf_counter() - t0 >= budget:
            break
    ms = (time.perf_counter() - t0) / runs * 1000
    return order, path, ms


# 3. Rendering helpers (all pre-rendered or cached where possible)
_text_cache = {}


def render(font, text, color):
    key = (id(font), text, color)
    surf = _text_cache.get(key)
    if surf is None:
        if len(_text_cache) > 500:
            _text_cache.clear()
        surf = font.render(text, True, color)
        _text_cache[key] = surf
    return surf


def txt(s, font, text, x, y, color=TEXT):
    s.blit(render(font, text, color), (x, y))


def lerp_color(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


def card(s, rect, title, small):
    pygame.draw.rect(s, CARD, rect, border_radius=12)
    pygame.draw.rect(s, EDGE, rect, 1, border_radius=12)
    if title:
        txt(s, small, title.upper(), rect.x + 14, rect.y + 10, MUTED)


def pill(s, small, x, y, on):
    pygame.draw.rect(s, ACCENT if on else EDGE, (x, y, 46, 20), border_radius=10)
    label = render(small, 'ON' if on else 'OFF', BG if on else MUTED)
    s.blit(label, label.get_rect(center=(x + 23, y + 10)))


def build_base(grid, cs, start):
    """Floor, walls and start cell, drawn once per maze."""
    n = len(grid)
    px = n * cs
    base = pygame.Surface((px, px))
    base.fill(FLOOR)
    rad = max(cs // 3, 2)
    for r in range(n):
        for c in range(n):
            if grid[r][c]:
                pygame.draw.rect(base, WALL,
                                 (c * cs + 1, r * cs + 1, cs - 2, cs - 2),
                                 border_radius=rad)
    sr, sc = start
    pygame.draw.rect(base, START,
                     (sc * cs + 2, sr * cs + 2, cs - 4, cs - 4),
                     border_radius=rad)
    return base


def make_glow(cs):
    """Soft halo drawn behind the player (built once per cell size)."""
    size = int(cs * 2.6)
    surf = pygame.Surface((size, size), pygame.SRCALPHA)
    c = size // 2
    for i in range(5, -1, -1):  # largest and faintest first
        radius = int(cs * (0.45 + 0.13 * i))
        alpha = 20 + 12 * (5 - i)
        pygame.draw.circle(surf, (*PLAYER, alpha), (c, c), radius)
    return surf


# 4. Game state
@dataclass
class Animation:
    algo: str
    order: list
    path: list
    optimal: int
    pos: int = 0


class Game:
    def __init__(self, seed=None):
        self.rng = random.Random(seed)
        self.size_i = 1
        self.loops = False
        self.junction = True
        self.algo = 'bfs'
        self.new_maze()

    @property
    def busy(self):
        return self.anim is not None or self.glide is not None

    def layer_center(self, p):
        """Pixel centre of a cell, relative to the maze layers."""
        cs = self.cell
        return (p[1] * cs + cs / 2, p[0] * cs + cs / 2)

    def screen_center(self, p):
        x, y = self.layer_center(p)
        return (MARGIN + x, MARGIN + y)

    def new_maze(self):
        self.n = SIZES[self.size_i]
        self.cell = MAZE_PX // self.n
        self.px = self.n * self.cell
        self.grid = make_maze(self.n, self.loops, self.rng)
        self.start = (1, 1)
        self.goal = (self.n - 2, self.n - 2)
        self.player = self.start
        self.anim = None
        self.glide = None
        self.moves = self.steps = 0
        self.won = False
        self.stats = (0.0, 0, 0)
        self.table = []

        _, best = search('bfs', self.grid, self.start, self.goal)
        if not best:  # cannot happen for a carved perfect maze
            raise RuntimeError('generated maze has no path')
        self.optimal = len(best) - 1

        self.base = build_base(self.grid, self.cell, self.start)
        self.overlay = pygame.Surface((self.px, self.px), pygame.SRCALPHA)
        self.glow = make_glow(self.cell)
        self.veil = pygame.Surface((self.px, self.px), pygame.SRCALPHA)
        self.veil.fill((15, 23, 42, 215))
        self.view = list(self.screen_center(self.player))
        self.msg = 'Reach the goal, or press SPACE for the AI solver.'

    def clear_overlay(self):
        self.overlay.fill((0, 0, 0, 0))

    # Painting onto the persistent overlay (only new cells are touched)
    def _paint_visit(self, p, t):
        cs = self.cell
        inset = max(cs // 5, 1)
        r, c = p
        color = lerp_color(VISIT_A, VISIT_B, t) + (210,)
        pygame.draw.rect(self.overlay, color,
                         (c * cs + inset, r * cs + inset,
                          cs - 2 * inset, cs - 2 * inset),
                         border_radius=max(cs // 3, 2))

    def _paint_path(self, path):
        if len(path) < 2:
            return
        cs = self.cell
        pts = [(int(c * cs + cs / 2), int(r * cs + cs / 2)) for r, c in path]
        pygame.draw.lines(self.overlay, PATH + (90,), False, pts,
                          max(cs // 2, 4))
        pygame.draw.lines(self.overlay, PATH + (255,), False, pts,
                          max(cs // 4, 3))

    def solve(self):
        if self.busy:
            return
        if self.player == self.goal:
            self.msg = 'You are already at the goal.'
            return
        order, path, ms = bench(self.algo, self.grid, self.player, self.goal)
        _, best = search('bfs', self.grid, self.player, self.goal)
        self.stats = (ms, len(order), max(len(path) - 1, 0))
        self.clear_overlay()
        self.anim = Animation(self.algo, order, path,
                              max(len(best) - 1, 0))
        self.msg = f'{INFO[self.algo][0]} is searching...'

    def compare(self):
        self.table = []
        for a in ALGOS:
            order, path, ms = bench(a, self.grid, self.player, self.goal)
            self.table.append(
                (INFO[a][0], len(order), max(len(path) - 1, 0), ms))
        self.msg = 'Comparison updated from your current position.'

    def update_anim(self):
        a = self.anim
        if a is None:
            return
        total = len(a.order)
        new_pos = min(a.pos + ANIM_STEP, total)
        for k in range(a.pos, new_pos):
            self._paint_visit(a.order[k], k / max(total - 1, 1))
        a.pos = new_pos
        if a.pos == total:
            self._paint_path(a.path)
            self.anim = None
            steps = max(len(a.path) - 1, 0)
            self.msg = (f'{INFO[a.algo][0]}: path of {steps} steps '
                        f'(shortest possible = {a.optimal})')

    def try_move(self, dr, dc):
        if self.busy or self.won:
            return
        nr, nc = self.player[0] + dr, self.player[1] + dc
        if self.grid[nr][nc]:
            return
        self.moves += 1
        self.glide = (dr, dc)
        self.clear_overlay()  # old solver trail no longer applies

    def step_glide(self):
        if self.glide is None:
            return
        dr, dc = self.glide
        nr, nc = self.player[0] + dr, self.player[1] + dc
        if self.grid[nr][nc]:
            self.glide = None
            return
        self.player = (nr, nc)
        self.steps += 1
        if self.player == self.goal:
            self.won, self.glide = True, None
            self.msg = (f'You win! {self.moves} moves, {self.steps} cells. '
                        f'Shortest possible: {self.optimal}.')
            return
        side = ((0, -1), (0, 1)) if dr else ((-1, 0), (1, 0))
        if self.junction and any(
            not self.grid[nr + a][nc + b] for a, b in side
        ):
            self.glide = None

    def handle_key(self, k):
        if k in MOVE_KEYS:
            self.try_move(*MOVE_KEYS[k])
        elif k in ALGO_KEYS:
            self.algo = ALGO_KEYS[k]
        elif k == pygame.K_SPACE:
            self.solve()
        elif k == pygame.K_c:
            self.compare()
        elif k == pygame.K_j:
            self.junction = not self.junction
        elif k == pygame.K_l:
            self.loops = not self.loops
            self.new_maze()
        elif k == pygame.K_g:
            self.size_i = (self.size_i + 1) % len(SIZES)
            self.new_maze()
        elif k == pygame.K_r:
            self.new_maze()

    # 5. Drawing
    def draw(self, s, fonts, now):
        big, font, small = fonts
        s.fill(BG)
        pygame.draw.rect(s, CARD, (MARGIN - 8, MARGIN - 8,
                                   self.px + 16, self.px + 16),
                         border_radius=14)
        s.blit(self.base, (MARGIN, MARGIN))
        s.blit(self.overlay, (MARGIN, MARGIN))
        self._draw_goal(s, now)
        self._draw_player(s)
        self._draw_bottom(s, font, small)
        self._draw_panel(s, big, font, small)
        if self.won:
            self._draw_win(s, big, font, small)

    def _draw_goal(self, s, now):
        gx, gy = self.screen_center(self.goal)
        pulse = (math.sin(now / 180) + 1) / 2
        r = int(self.cell * (0.22 + 0.06 * pulse))
        pygame.draw.circle(s, GOAL, (int(gx), int(gy)), r)

    def _draw_player(self, s):
        tx, ty = self.screen_center(self.player)
        self.view[0] += (tx - self.view[0]) * 0.35  # smooth glide
        self.view[1] += (ty - self.view[1]) * 0.35
        vx, vy = int(self.view[0]), int(self.view[1])
        gw = self.glow.get_width()
        s.blit(self.glow, (vx - gw // 2, vy - gw // 2))
        radius = int(self.cell * 0.34)
        pygame.draw.circle(s, PLAYER, (vx, vy), radius)
        pygame.draw.circle(s, (255, 255, 255), (vx, vy), radius, 2)

    def _draw_bottom(self, s, font, small):
        txt(s, font, self.msg, MARGIN, 576)
        items = [('Start', START), ('Goal', GOAL), ('Visited', VISIT_B),
                 ('Path', PATH), ('Player', PLAYER)]
        for i, (name, col) in enumerate(items):
            x = MARGIN + i * 100
            pygame.draw.rect(s, col, (x, 606, 12, 12), border_radius=3)
            txt(s, small, name, x + 18, 603, MUTED)
        txt(s, small,
            'Arrows/WASD move   |   SPACE solve   |   C compare   |   '
            'R new maze   |   ESC quit',
            MARGIN, 636, MUTED)

    def _draw_win(self, s, big, font, small):
        # Dim the maze, then show the result on a solid card so it stays readable
        s.blit(self.veil, (MARGIN, MARGIN))
        cx = MARGIN + self.px // 2
        cy = MARGIN + self.px // 2
        title = render(big, 'You win!', ACCENT)
        sub = render(font, f'{self.moves} moves, {self.steps} cells  |  '
                           f'shortest possible: {self.optimal}', TEXT)
        hint = render(small, 'Press R to play again', MUTED)
        width = max(sub.get_width(), title.get_width()) + 60
        box = pygame.Rect(0, 0, width, 130)
        box.center = (cx, cy)
        pygame.draw.rect(s, CARD, box, border_radius=16)
        pygame.draw.rect(s, ACCENT, box, 2, border_radius=16)
        s.blit(title, title.get_rect(center=(cx, box.top + 36)))
        s.blit(sub, sub.get_rect(center=(cx, box.top + 72)))
        s.blit(hint, hint.get_rect(center=(cx, box.top + 102)))

    def _draw_panel(self, s, big, font, small):
        X, PW = PANEL_X, 350
        txt(s, big, 'Maze AI', X + 4, 12, TEXT)
        txt(s, small, 'Pathfinding visualiser', X + 4, 38, MUTED)

        # Algorithm selection
        card(s, pygame.Rect(X, 62, PW, 166), 'Algorithm  (keys 1-4)', small)
        for i, a in enumerate(ALGOS):
            y = 92 + i * 26
            on = a == self.algo
            if on:
                pygame.draw.rect(s, EDGE, (X + 8, y - 4, PW - 16, 22),
                                 border_radius=6)
            name, tc, _, _ = INFO[a]
            txt(s, font, f'{i + 1}.  {name}', X + 16, y - 2,
                ACCENT if on else TEXT)
            hint = render(small, tc, MUTED)
            s.blit(hint, (X + PW - 14 - hint.get_width(), y + 2))
        _, _, sc, opt = INFO[self.algo]
        txt(s, small, f'Space {sc}   |   Always shortest: {opt}',
            X + 14, 204, MUTED)

        # Settings
        card(s, pygame.Rect(X, 240, PW, 90), 'Settings', small)
        txt(s, font, '[G] Grid size', X + 14, 262)
        txt(s, font, f'{self.n} x {self.n}', X + PW - 70, 262, ACCENT)
        txt(s, font, '[L] Loops', X + 14, 284)
        pill(s, small, X + PW - 60, 284, self.loops)
        txt(s, font, '[J] Stop at junctions', X + 14, 306)
        pill(s, small, X + PW - 60, 306, self.junction)

        # Metrics
        card(s, pygame.Rect(X, 340, PW, 108), 'Metrics', small)
        cols = [X + 14, X + 180]
        metrics = [
            [('Time', f'{self.stats[0]:.3f} ms'),
             ('Nodes explored', f'{self.stats[1]}')],
            [('Path length', f'{self.stats[2]}'),
             ('Player moves', f'{self.moves}')],
        ]
        for row, pair in enumerate(metrics):
            for col, (label, value) in enumerate(pair):
                y = 366 + row * 40
                txt(s, small, label, cols[col], y, MUTED)
                txt(s, font, value, cols[col], y + 16)

        # Comparison
        card(s, pygame.Rect(X, 460, PW, 108), 'Compare  (press C)', small)
        if not self.table:
            txt(s, small, 'Compare all four from your current cell.',
                X + 14, 500, MUTED)
        else:
            heads = ['Algo', 'Nodes', 'Path', 'ms']
            offs = [14, 130, 210, 270]
            for j, h in enumerate(heads):
                txt(s, small, h, X + offs[j], 484, MUTED)
            for i, (name, nodes, plen, ms) in enumerate(self.table):
                y = 500 + i * 15
                current = name == INFO[self.algo][0]
                color = ACCENT if current else TEXT
                for j, val in enumerate([name, str(nodes), str(plen),
                                         f'{ms:.3f}']):
                    txt(s, small, val, X + offs[j], y, color)


# 6. Main loop
def main(argv=None):
    parser = argparse.ArgumentParser(description='Maze game with pathfinding AI')
    parser.add_argument('--seed', type=int, default=None,
                        help='fixed seed for reproducible mazes')
    args = parser.parse_args(argv)

    pygame.init()
    try:
        # RESIZABLE is required for the Restore Down / Maximize buttons to work.
        screen = pygame.display.set_mode((W, H), pygame.RESIZABLE)
        canvas = pygame.Surface((W, H))  # fixed-size scene, scaled to the window
        pygame.display.set_caption('Maze Game & Pathfinding AI')
        fonts = [
            pygame.font.SysFont('segoeui,arial', sz, bold=b)
            for sz, b in ((22, True), (16, False), (13, False))
        ]
        clock = pygame.time.Clock()
        game = Game(args.seed)
        last_glide = 0
        while True:
            for e in pygame.event.get():
                if e.type == pygame.QUIT:
                    return
                if e.type == pygame.VIDEORESIZE:
                    # Restore Down / maximize / drag-resize: take the new size
                    screen = pygame.display.set_mode(
                        (max(e.w, 200), max(e.h, 200)), pygame.RESIZABLE)
                if e.type == pygame.KEYDOWN:
                    if e.key == pygame.K_ESCAPE:
                        return
                    game.handle_key(e.key)
            now = pygame.time.get_ticks()
            if game.glide and now - last_glide > GLIDE_MS:
                game.step_glide()
                last_glide = now
            game.update_anim()
            game.draw(canvas, fonts, now)
            # Scale the scene to fit the current window, keeping its shape
            sw, sh = screen.get_size()
            scale = min(sw / W, sh / H)
            dw, dh = max(int(W * scale), 1), max(int(H * scale), 1)
            scaled = pygame.transform.smoothscale(canvas, (dw, dh))
            screen.fill(BG)
            screen.blit(scaled, ((sw - dw) // 2, (sh - dh) // 2))
            pygame.display.flip()
            clock.tick(FPS)
    finally:
        pygame.quit()


if __name__ == '__main__':
    main()